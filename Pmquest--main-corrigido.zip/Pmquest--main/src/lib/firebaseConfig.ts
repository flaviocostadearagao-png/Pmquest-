export const firebaseConfig = {
  projectId: "gen-lang-client-0178137491",
  appId: "1:1026633886451:web:3d88b94b1f360f3c3ba586",
  apiKey: "AIzaSyDs8HxYKt3qvWqUIPj-1H3QmMhv9tpTGXY",
  authDomain: "gen-lang-client-0178137491.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-simuladopmbaques-1e5a701e-180f-4568-9f11-eb22c65830da",
  storageBucket: "gen-lang-client-0178137491.firebasestorage.app",
  messagingSenderId: "1026633886451",
  measurementId: "",
  oAuthClientId: "1026633886451-863mubmo0gsfctnpcr9g49etfut90br2.apps.googleusercontent.com",
  recaptchaSiteKey: ""
};
